interface VisitorInsightsProps {
  'New Visitors': number[];
}

export const visitorInsightsData: VisitorInsightsProps = {
  'New Visitors': [210, 115, 440, 370, 320, 500, 270, 450, 381, 245, 212, 333],
};
